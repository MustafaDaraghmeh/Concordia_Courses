
### concordia - udemy courses
* https://concordia.udemy.com/course/java-se-programming/
* https://concordia.udemy.com/course/datastructurescncpp/
* https://concordia.udemy.com/course/data-structures-and-algorithms-deep-dive-using-java/

### coursera
* https://www.coursera.org/specializations/java-object-oriented 

### concordia - oreilly
* https://learning.oreilly.com/library/view/algorithms-fourth-edition/9780132762564/
* https://learning.oreilly.com/videos/algorithms-24-part-lecture/9780134384528/
* https://learning.oreilly.com/library/view/java-how-to/9780134751962/
* https://learning.oreilly.com/library/view/algorithms-in-a/9780596516246/

### Web resources
* https://www.java67.com/2019/07/top-10-online-courses-to-learn-data-structure-and-algorithms-in-java.html
* https://www.w3schools.com/java/default.asp
* https://www.tutorialspoint.com/java/index.htm
* https://www.tutorialspoint.com/data_structures_algorithms/index.htm

### Cheatsheet
* https://cheatography.com/burcuco/cheat-sheets/data-structures-and-algorithms/
* https://algs4.cs.princeton.edu/cheatsheet/
* https://medium.com/@stephen_gou/data-structures-and-algorithms-cheat-sheet-b06c7ff5515f
* https://github.com/gibsjose/cpp-cheat-sheet/blob/master/Data%20Structures%20and%20Algorithms.md
* https://medium.com/geekculture/data-structures-cheat-sheet-58ad168c9bbe
* https://www.interviewcake.com/data-structures-reference
* https://cheatography.com/meliodas/cheat-sheets/algorithms-and-datastructures-java/pdf_bw/
* https://www.javaguides.net/p/data-structures-and-algorithms-in-java.html
* https://www.codecademy.com/learn/java-algorithms/modules/apcs-searching-and-sorting/cheatsheet
* https://www.codecademy.com/learn/java-for-programmers/modules/java-for-programmers-built-in-data-structures/cheatsheet
* https://cheatography.com/ieternalleo/cheat-sheets/java-data-structures/pdf_bw/
* https://www.geeksforgeeks.org/fundamentals-of-algorithms/?ref=shm
* https://www.geeksforgeeks.org/data-structures/?ref=shm
