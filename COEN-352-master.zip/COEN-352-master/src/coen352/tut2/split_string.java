package coen352.tut2;

import java.util.Arrays;
import java.io.File;  // Import the File class
import java.io.FileNotFoundException;  // Import this class to handle errors
import java.util.Scanner; // Import the Scanner class to read text files

public class split_string{

	public static void main(String[] args) {
		// [20, 35, -15, 7, 55, 1, -22]
		int [] intArray = read_int(args[0]);
		System.out.println(Arrays.toString(intArray));

		// search for item index
		int item = 7;
		int index = -1;
		for (int i = 0; i < intArray.length; i++) {
			if (intArray[i] == item) {
				index = i;
				break;
			}
		}
		System.out.println("index = " + index);
	}

	public static int [] read_int(String file_name){
		String data="";
		try {
			Scanner Reader = new Scanner(new File(file_name));
			if(Reader.hasNextLine()) {
				data = Reader.nextLine();
			}
//			while (Reader.hasNextLine()) {
//				data = Reader.nextLine();
////				break; // to read the first line only
//			}
			Reader.close();
		} catch (FileNotFoundException e) {
			System.out.println("An error occurred.");
			e.printStackTrace();
		}

		//split string
		String[] splits = data.split(" ");

		int array_length = splits.length;

		int []  integer_array = new int [array_length];

		for(int i=0; i<array_length; i++) {
			integer_array[i] = Integer.parseInt(splits[i]);
		}
		return integer_array;
	}
}