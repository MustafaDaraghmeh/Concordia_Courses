/*
 *  2020. Mustafa Daraghmeh.
 */

package coen352.tut3;

// Java program to implement Queue using two stacks with costly enQueue()
// ref: https://www.javatpoint.com/implementation-of-queue-using-stacks
import java.util.*;
// exercise
public class Queue_Exercise_01 {
    public static class Queue {
        Stack<Integer> stack_01 = new Stack<>();
        Stack<Integer> stack_02 = new Stack<>();

        void enQueue(int x) {
            // Move all elements from stack_01 to stack_02
            while (!stack_01.isEmpty()) {  //n
                stack_02.push(stack_01.pop());
                //stack_01.pop();
            }

            // Push item into stack_01
            stack_01.push(x);

            // Push everything back to stack_01
            while (!stack_02.isEmpty()) { //n
                stack_01.push(stack_02.pop());
                //stack_02.pop();
            }
        }

        // Dequeue an item from the queue
        int deQueue() {
            // if first stack is empty
            if (stack_01.isEmpty()) {
                System.out.println("Q is Empty");
                System.exit(0);
            }

            // Return top of s1
            int top = stack_01.peek();
            stack_01.pop();
            return top;
        }
    }

    // Driver code
    public static void main(String[] args) {
        Queue queue = new Queue();
        queue.enQueue(1);
        queue.enQueue(2);
        queue.enQueue(3);

        System.out.println(queue.deQueue());
        System.out.println(queue.deQueue());
        System.out.println(queue.deQueue());
    }
}