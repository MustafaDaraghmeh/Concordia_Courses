/*
 *  2020. Mustafa Daraghmeh.
 */

package coen352.tut3;

// Java program to implement Queue using two stacks with costly deQueue()
// ref: https://www.javatpoint.com/implementation-of-queue-using-stacks
import java.util.Stack;

class Queue_Exercise_02 {
    static class Queue {
        Stack<Integer> stack_01 = new Stack<Integer>();
        Stack<Integer> stack_02 = new Stack<Integer>();

        void enQueue(int x) {
            // Push item into stack_01
            stack_01.push(x);
        }

        // Dequeue an item from the queue
        int deQueue() {
            // if first stack is empty
            if (stack_01.isEmpty()) {
                System.out.println("Q is Empty");
                System.exit(0);
            }
            while (!stack_01.isEmpty()) {
                stack_02.push(stack_01.pop());
            }
            // Return top of stack_02
            int top = stack_02.peek();
            stack_02.pop();
            while (!stack_02.isEmpty()) {
                stack_01.push(stack_02.pop());
            }
            return top;
        }
    }

    // Driver code
    public static void main(String[] args) {
        Queue queue = new Queue();
        queue.enQueue(1);
        queue.enQueue(2);
        queue.enQueue(3);

        System.out.println(queue.deQueue());
        System.out.println(queue.deQueue());
        System.out.println(queue.deQueue());
    }
}