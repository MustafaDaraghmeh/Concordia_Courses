/*
 *  2020. Mustafa Daraghmeh.
 */

package coen352.tut3;
/* Java Program to implement a stack using two queue with costly push()
* Ref: https://www.javatpoint.com/implementation-of-stack-using-queue
* */

import java.util.*;
public class Stack_Exercise_02 {

    static class Stack {
        // Two inbuilt queues
        static Queue<Integer> queue_01 = new LinkedList<Integer>();
        static Queue<Integer> queue_02 = new LinkedList<Integer>();

        // To maintain current number of
        // elements
        static int curr_size;

        Stack() {
            curr_size = 0;
        }

        void push(int x) {
            curr_size++;

            // Push x first in empty q2
            queue_02.add(x);

            // Push all the remaining
            // elements in q1 to q2.
            while (!queue_01.isEmpty()) {
                queue_02.add(queue_01.peek());
                queue_01.remove();
            }

            // swap the names of two queues
            Queue<Integer> q = queue_01;
            queue_01 = queue_02;
            queue_02 = q;
        }

        void pop() {

            // if no elements are there in q1
            if (queue_01.isEmpty())
                return;
            queue_01.remove();
            curr_size--;
        }

        static int top() {
            if (queue_01.isEmpty())
                return -1;
            return queue_01.peek();
        }

        int size() {
            return curr_size;
        }
    }

    // driver code
    public static void main(String[] args) {
        Stack s = new Stack();
        s.push(1);
        s.push(2);
        s.push(3);

        System.out.println("current size: " + s.size());

        System.out.println(Stack.top());
        s.pop();
        System.out.println(Stack.top());
        s.pop();
        System.out.println(Stack.top());

        System.out.println("current size: " + s.size());
    }
}
