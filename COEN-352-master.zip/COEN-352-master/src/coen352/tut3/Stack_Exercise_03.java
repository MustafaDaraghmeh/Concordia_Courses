/*
 *  2022. Mustafa Daraghmeh.
 */

package coen352.tut3;

import java.util.*;

public class Stack_Exercise_03 {
//    In computer science, a stack or LIFO (last in, first out) is an abstract data type that serves as a collection
//    of elements, with two principal operations: push, which adds an element to the collection, and pop, which removes
//    the last element that was added.(Wikipedia)

//    Problem: determine the balanced string containing parentheses
    //    Examples of some correctly balanced strings are: “{any_text}(any_text)”, “[{(any_text)}]”, “({(any_text)})”
    //    Examples of some unbalanced strings are: “{}(“, “({)}”, “[[“, “}{” etc.
//
//    Given a string, determine if it is balanced or not.
//    Sample input
//    {}()
//    ({()})
//    {}(
//    []
//    Output
//     true
//     true
//     false
//     true
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        while(sc.hasNext()) {
            String input = sc.next();
            System.out.println(balanced_string(input));
        }
    }

    public static boolean balanced_string(String s) {
        Stack<Character> stack = new Stack<Character>();

        for(int i = 0; i < s.length(); i++) {
            char c = s.charAt(i);
            if(c =='[' || c == '(' || c == '{') {
                stack.push(c);
            }else if(c == ']') {
                if(stack.isEmpty() || stack.pop() != '[') {
                    return false;
                }
            }else if(c == ')') {
                if(stack.isEmpty() || stack.pop() != '(') {
                    return false;
                }
            }else if(c == '}') {
                if(stack.isEmpty() || stack.pop() != '{') {
                    return false;
                }
            }
        }
        return stack.isEmpty();
    }
}