#pragma once
#include <string>
#include "Date.h"
#include <iostream>
using namespace std;
class Person
{
public:
	// Constructor
	Person();
	Person(string _name);
	virtual void print() = 0;
	/*Person& operator=(Person& orig);*/
	void setName(string name);
	string getName();
	
	int getID();
	void setID(int _Id);

	
protected:
	static int nextId;
private:
	int uniqueID;
	string name; // person's name
};
