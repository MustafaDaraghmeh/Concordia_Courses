#pragma once
#include "Person.h"
class Doctor :
	public Person
{
public:
	Doctor(string _name, string _medicalLicenseNumber, string _specialty);
	
	void print();

	void setID(string _medicalLicenseNumber);
	string getID();
	void addPatient(Person& _Patient);
	void printListOfPatients();

private:
	string medicalLicenseNumber;
	string specialty;//(e.g., orthopedist, pediatrician, etc.)
	Person** listOfPatients;
	int amountOfPatient;
};

