#include "Outpatient.h"
OutPatient::OutPatient(string _name, Date _appointmentDate, Time _appointmentTime, Doctor _assignedDoctor, double _hospitalCharge)
	: Person(_name), appointmentDate{ _appointmentDate }, appointmentTime{ _appointmentTime }, assignedDoctor{ _assignedDoctor }, hospitalCharge{ _hospitalCharge }
{
	//Person::setName(_name);
	Person::setID(++nextId);
}
void OutPatient::print() {
	cout << "OutPatient" << endl;
}
void OutPatient::setAppointmentDate(Date _appointmentDate)
{
	appointmentDate = _appointmentDate;
}

void OutPatient::setAppointmentTime(Time _appointmentTime)
{
	appointmentTime = _appointmentTime;
}

void OutPatient::setHospitalCharge(double _hospitalCharge)
{
	hospitalCharge = _hospitalCharge;
}

void OutPatient::setAssignedDoctor(Doctor _assignedDoctor)
{
	assignedDoctor = _assignedDoctor;
}

Date OutPatient::getAppointmentDate()
{
	return appointmentDate;
}

Time OutPatient::getAppointmentTime()
{
	return appointmentTime;
}

double OutPatient::getHospitalCharge()
{
	return hospitalCharge;
}

Doctor OutPatient::getAssignedDoctor()
{
	return assignedDoctor;
}
