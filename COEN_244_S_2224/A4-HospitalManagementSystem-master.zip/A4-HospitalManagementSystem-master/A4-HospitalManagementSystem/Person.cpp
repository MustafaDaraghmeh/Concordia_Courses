#include "Person.h"
int Person::nextId = 0;
Person::Person() = default;
// Constructor
Person::Person(string _name) : name{ _name }{	}

//Person& Person::operator=(Person& orig)
//{
//		setID(orig.getID());
//		setName(orig.getName());
//		return(*this);
//}

// set name
void Person::setName(string _name) {
	name = _name;
}
// get name
string Person::getName() {
	return  name;
}

//set ID
void Person::setID(int _Id) {
	uniqueID = _Id;
}
// get ID
int Person::getID() {
	return uniqueID;
}

