#include "Person.h"
#include "Doctor.h"

Doctor::Doctor(string _name, string _medicalLicenseNumber, string _specialty)
	:Person(_name), medicalLicenseNumber{ _medicalLicenseNumber }, specialty{ _specialty }, amountOfPatient{0}
{
	
}
void Doctor::print()
{
	cout << "Doctor" << endl;
}

void Doctor::setID(string mln)
{
	medicalLicenseNumber = mln;
}
// get ID
string Doctor::getID() {
	return medicalLicenseNumber;
}

void Doctor::addPatient(Person &_Patient)
{
	if (amountOfPatient == 0) {
		listOfPatients = new Person*[++amountOfPatient];
		listOfPatients[amountOfPatient - 1] = &_Patient;
	}
	else {
		Person** tempArray = new Person*[++amountOfPatient];
		
		for (int i = 0; i < amountOfPatient-1; i++) {
			tempArray[i] = listOfPatients[i];
		}
		//std::copy(listOfPatients, listOfPatients + (amountOfPatient-1), tempArray);

		delete[] listOfPatients;

		listOfPatients = tempArray;
		listOfPatients[amountOfPatient - 1] = &_Patient;	
	}
}

void Doctor::printListOfPatients()
{
	for (int i = 0; i < amountOfPatient; i++) {
		std::cout<<"\n"<<listOfPatients[i]->getID()<<"\n";
		std::cout << "\n" << listOfPatients[i]->getName() << "\n";
		 listOfPatients[i]->print();
	}
}
