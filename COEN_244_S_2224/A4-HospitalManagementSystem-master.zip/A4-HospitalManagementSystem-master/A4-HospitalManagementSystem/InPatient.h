#pragma once
#include "Person.h"
#include "Doctor.h"
class InPatient :
	public Person
{
public:
	InPatient(string _name, Date _admissionDate, Date _dischargeDate, Doctor _assignedDoctor,int _bedNumber, double _dailyCharge);
	void print();
	Date getAdmissionDate();
	Date getDisChargeDate();
	Doctor getAssignedDoctor();
	int getBedNumber();
	double getDailyCharge();

	void setAdmissionDate(Date _admissionDate);
	void setDisChargeDate(Date _dischargeDate);
	void setAssignedDoctor(Doctor _assignedDoctor);
	void setBedNumber(int _bedNumber);
	void setDailyCharge(double _dailyCharge);
private:
	Date admissionDate;
	Date disChargeDate;
	Doctor assignedDoctor; //Doctor who provided treatment
	int bedNumber;
	double dailyCharge;
};

