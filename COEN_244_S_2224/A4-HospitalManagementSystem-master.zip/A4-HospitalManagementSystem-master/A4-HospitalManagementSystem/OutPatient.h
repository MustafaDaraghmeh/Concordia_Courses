#pragma once
#include "Person.h"
#include "Time.h"
#include "Doctor.h"
class OutPatient :
	public Person
{
public:
	OutPatient(string _name, Date _appointmentDate, Time _appointmentTime, Doctor _assignedDoctor, double _hospitalCharge);
	void print();

	void setAppointmentDate(Date _appointmentDate);
	void setAppointmentTime(Time _appointmentTime);
	void setHospitalCharge(double _hospitalCharge);
	void setAssignedDoctor(Doctor _assignedDoctor);

	Date getAppointmentDate();
	Time getAppointmentTime();
	double getHospitalCharge();
	Doctor getAssignedDoctor();
private:
	Date appointmentDate;
	Time appointmentTime;
	double hospitalCharge;
	Doctor assignedDoctor; //Doctor who provided treatment
};

