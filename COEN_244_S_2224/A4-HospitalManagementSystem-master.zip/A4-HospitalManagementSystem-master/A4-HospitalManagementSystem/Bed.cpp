#include "Bed.h"
int Bed::nextId = 0;
Bed::Bed()
{
	setId(++nextId);
	setAvaiable(1);
}

void Bed::setId(int _id)
{
	id = _id;
}

void Bed::setAvaiable(bool _avaiable)
{
	avaiable = _avaiable;
}

int Bed::getId()
{
	return id;
}

bool Bed::getAvaiable()
{
	return avaiable;
}
