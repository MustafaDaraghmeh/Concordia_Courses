#pragma once
class Bed
{
public:
	Bed();
	void setId(int _id);
	void setAvaiable(bool _avaiable);
	int getId();
	bool getAvaiable();
protected:
	static int nextId;
private:
	int id;
	bool avaiable;
};

