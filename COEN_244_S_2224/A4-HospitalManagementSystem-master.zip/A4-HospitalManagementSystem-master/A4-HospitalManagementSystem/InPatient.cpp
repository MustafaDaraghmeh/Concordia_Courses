#include "InPatient.h"

InPatient::InPatient(string _name, Date _admissionDate, Date _dischargeDate, Doctor _assignedDoctor, int _bedNumber, double _dailyCharge)
	: Person(_name), admissionDate{ _admissionDate }, disChargeDate{ _dischargeDate }, assignedDoctor{ _assignedDoctor }, bedNumber{ _bedNumber }, dailyCharge{ _dailyCharge }
{
	Person::setID(++nextId);
}
void InPatient::print() {
	cout << "InPatient" << endl;
}
#pragma region MyRegion

Date InPatient::getAdmissionDate()
{
	return admissionDate;
}

Date InPatient::getDisChargeDate()
{
	return disChargeDate;
}

Doctor InPatient::getAssignedDoctor()
{
	return assignedDoctor;
}

int InPatient::getBedNumber()
{
	return bedNumber;
}

double InPatient::getDailyCharge()
{
	return dailyCharge;
}

void InPatient::setAdmissionDate(Date _admissionDate)
{
	admissionDate = _admissionDate;
}

void InPatient::setDisChargeDate(Date _dischargeDate)
{
	disChargeDate = _dischargeDate;
}

void InPatient::setAssignedDoctor(Doctor _assignedDoctor)
{
	assignedDoctor = _assignedDoctor;
}

void InPatient::setBedNumber(int _bedNumber)
{
	bedNumber = _bedNumber;
}

void InPatient::setDailyCharge(double _dailyCharge)
{
	dailyCharge = _dailyCharge;
}
#pragma endregion