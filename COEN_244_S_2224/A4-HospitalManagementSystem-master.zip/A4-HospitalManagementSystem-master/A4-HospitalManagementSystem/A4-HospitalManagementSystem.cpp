// A4-HospitalManagementSystem.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include <iostream>
#include "Date.h" // include definitions of class Date
#include "Time.h"
#include "Person.h"
#include "Doctor.h"
#include "InPatient.h"
#include"OutPatient.h"
#include "Bed.h"

using namespace std;

int main()
{
	Date d{ 12, 24, 2013 }; // instantiate object d of class Date
	// output Date object d's value
		cout << d.toString() << endl;

	Time t{ 23, 59, 57 }; // instantiate object t of class Time
		cout << t.toStandardString() << endl;
		
		Doctor dr("Mustafa", "mln", "sp");
		// display user information
		cout << "\nID: " << dr.getID();
		cout << "\nDoctor Name: " << dr.getName();

		InPatient ip("ALI1",d,d,dr,5,0.55);
		cout << "\nID: " << ip.getID();
		cout << "\nInPatient Name: " << ip.getName();

		OutPatient op("ALI2",d,t,dr,0.55);
		cout << "\nID: " << op.getID();
		cout << "\nOutPatient Name: " << op.getName();

		OutPatient op3("ALI3", d, t, dr, 0.55);
		cout << "\nID: " << op3.getID();
		cout << "\nOutPatient Name: " << op3.getName();

		Bed b1;
		cout << "\nID: " << b1.getId();
		cout << "\nAvailablity: " << b1.getAvaiable();
		Bed b2;
		cout << "\nID: " << b2.getId();
		cout << "\nAvailablity: " << b2.getAvaiable();
		dr.addPatient(ip);
		dr.addPatient(op);
		dr.addPatient(op3);

		dr.printListOfPatients();
}