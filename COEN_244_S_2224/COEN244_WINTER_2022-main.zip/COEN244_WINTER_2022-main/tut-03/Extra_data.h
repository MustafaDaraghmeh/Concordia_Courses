//
// Created by musta on 2022-01-28.
//

#ifndef COEN244_WINTER_2022_EXTRA_DATA_H
#define COEN244_WINTER_2022_EXTRA_DATA_H


class Extra_data {
public:
    Extra_data();
    Extra_data(int);
    int data;
};


#endif //COEN244_WINTER_2022_EXTRA_DATA_H
