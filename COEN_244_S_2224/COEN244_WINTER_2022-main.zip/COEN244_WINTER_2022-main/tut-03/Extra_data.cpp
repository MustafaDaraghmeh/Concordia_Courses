//
// Created by musta on 2022-01-28.
//

#include "Extra_data.h"

Extra_data::Extra_data() {
this->data=0;
}

Extra_data::Extra_data(int d) {
    this->data=d;
}
