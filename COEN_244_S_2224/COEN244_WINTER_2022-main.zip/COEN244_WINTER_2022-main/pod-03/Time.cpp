//
// Created by musta on 2022-01-28.
//

#include "Time.h"

Time::Time(int h, int m, int s) {
    this->h=h;
    this->m=m;
    this->s=s;
}

Time::Time(): h(0),m(0), s(0){

}
