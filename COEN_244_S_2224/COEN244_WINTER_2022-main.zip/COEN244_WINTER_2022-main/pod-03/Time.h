//
// Created by musta on 2022-01-28.
//

#ifndef COEN244_WINTER_2022_TIME_H
#define COEN244_WINTER_2022_TIME_H


class Time {
    int h;
    int m;
    int s;
public:
    Time();
    Time(int h, int m, int s);
};


#endif //COEN244_WINTER_2022_TIME_H
