#pragma once
#include <string>
using namespace std;
class Reference
{
public:
	Reference();
	Reference(string Title, string Author, int YearOfPublication);
	Reference(const Reference& orig);

	Reference& operator=(const Reference& orig);

	void setUniqueIdentifier();
	bool setUniqueIdentifier(int id);
	bool setTitle(string t);
	bool setAuthor(string a);
	bool setYearOfPublication(int y);

	int getUniqueIdentifier() const;
	string getTitle() const;
	string getAuthor() const;
	int getYearOfPublication() const;

	virtual void printData() const;

protected:
	static int nextID;

private:
	int uniqueIdentifier;
	string title;
	string author;
	int yearOfPublication;
};
