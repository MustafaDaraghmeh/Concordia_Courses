#include "Reference.h"
#include <iostream>

int Reference::nextID = 0;

Reference::Reference() = default;

Reference::Reference(string Title, string Author, int YearOfPublication)
{
	setUniqueIdentifier();
	setTitle(Title);
	setAuthor(Author);
	setYearOfPublication(YearOfPublication);
}

Reference::Reference(const Reference& orig) {
	setUniqueIdentifier(orig.getUniqueIdentifier());
	setTitle(orig.getTitle());
	setAuthor(orig.getAuthor());
	setYearOfPublication(orig.getYearOfPublication());
}

Reference& Reference::operator=(const Reference& orig) {
	setUniqueIdentifier(orig.getUniqueIdentifier());
	setTitle(orig.getTitle());
	setAuthor(orig.getAuthor());
	setYearOfPublication(orig.getYearOfPublication());

	return(*this);
}

void Reference::setUniqueIdentifier()
{
	setUniqueIdentifier(++nextID);
}
bool Reference::setUniqueIdentifier(int id)
{
	if (id != NULL) {
		uniqueIdentifier = id;
		return true;
	}
	else {
		cout << "Error: setUniqueIdentifier..............." << endl;
		return false;
	}
}
bool Reference::setTitle(string t)
{
	if (t != "") {
		title = t;
		return true;
	}
	else {
		cout << "Error: setTitle..............." << endl;
		return false;
	}
}
bool Reference::setAuthor(string a)
{
	if (a != "") {
		author = a;
		return true;
	}
	else {
		cout << "Error: setAuthor..............." << endl;
		return false;
	}
}
bool Reference::setYearOfPublication(int y)
{
	if (y != NULL) {
		yearOfPublication = y;
		return true;
	}
	else {
		cout << "Error: setYearOfPublication..............." << endl;
		return false;
	}
}

int Reference::getUniqueIdentifier() const
{
	return uniqueIdentifier;
}
string Reference::getTitle() const
{
	return title;
}
string Reference::getAuthor() const
{
	return author;
}
int Reference::getYearOfPublication() const
{
	return yearOfPublication;
}

void Reference::printData() const {
	cout << "Type: Reference" << endl;
	cout << "ID: " << getUniqueIdentifier() << endl;
	cout << "Title: " << getTitle() << endl;
	cout << "Author: " << getAuthor() << endl;
	cout << "Year: " << getYearOfPublication() << endl << endl;
}