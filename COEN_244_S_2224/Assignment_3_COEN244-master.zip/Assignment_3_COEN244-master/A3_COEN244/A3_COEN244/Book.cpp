#include "Book.h"
#include <iostream>


Book::Book() = default;

Book::Book(string Title, string Author, int YearOfPublication, string Publisher, int NumberOfPages) :
	Reference(Title, Author, YearOfPublication)
{
	setPublisher(Publisher);
	setNumberOfPages(NumberOfPages);
}

Book& Book::operator=(const Book& orig)
{
	setUniqueIdentifier(orig.getUniqueIdentifier());
	setTitle(orig.getTitle());
	setAuthor(orig.getAuthor());
	setYearOfPublication(orig.getYearOfPublication());
	setPublisher(orig.getPublisher());
	setNumberOfPages(orig.getNumberOfPages());
	return(*this);
}

// returns total book pages number
int Book::getNumberOfPages() const
{
	return numberOfPages;
}
string Book::getPublisher() const
{
	return string(publisher);
}

bool Book::setNumberOfPages(int n)
{
	if (n != NULL) {
		numberOfPages = n;
		return true;
	}
	else {
		cout << "Error: setNumberOfPages..............." << endl;
		return false;
	}
}
bool Book::setPublisher(string p)
{
	if (p != "") {
		publisher = p;
		return true;
	}
	else {
		cout << "Error: setPublisher..............." << endl;
		return false;
	}
}

void Book::printData() const {
	cout << "Type: Book" << endl;
	cout << "ID: " << getUniqueIdentifier() << endl;
	cout << "Title: " << getTitle() << endl;
	cout << "Author: " << getAuthor() << endl;
	cout << "Year: " << getYearOfPublication() << endl;
	cout << "Publisher: " << getPublisher() << endl;
	cout << "Total Page Number: " << getNumberOfPages() << endl << endl;

}