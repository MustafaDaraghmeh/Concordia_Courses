#pragma once
#include "Reference.h"
class Book :
	public Reference
{
public:
	Book();
	Book(string Title, string Author, int YearOfPublication, string Publisher, int NumberOfPages);
	Book& operator=(const Book& orig);

	// returns total number of book pages
	int getNumberOfPages() const;
	string getPublisher() const;

	bool setNumberOfPages(int n);
	bool setPublisher(string p);

	void printData() const;

private:
	string publisher;
	int numberOfPages;
};

