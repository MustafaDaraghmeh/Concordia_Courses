#include "ReferenceManager.h"
#include <iostream>
#include <cassert>

ReferenceManager::ReferenceManager(int capacity) :
	size{ capacity }, tailPosition{ 0 }
{
	assert(size >= 0);
	if (size > 0) {
		References = new Reference * [size];
		for (int i = 0; i < size; i++) References[i] = nullptr;
	}
}

int ReferenceManager::getReferenceID(int index) const
{
	return (References[index]->getUniqueIdentifier());
}

bool ReferenceManager::add(Reference& orig)
{
	if (!isFull()) {
		References[tailPosition] = &orig;
		cout << "\n\nInfo:The Follwing Recored Is Added Succusfully:\n\n";
		References[tailPosition]->printData();
		tailPosition++;
		return true;
	}
	else {
		cout << "Erorr: The Container Is Full\n";
		cout << "Total location: " << size << "\tAllocated: " << tailPosition << "\tAvailable: " << getAvailableLocation() << endl;
		return false;
	}
}

bool  ReferenceManager::removeByIndex(int index) {
	// Sanity check our index value
	assert(index >= 0 && index < tailPosition);
	if (index >= 0 && index < tailPosition) {
		if (tailPosition == 1) {
			cout << "Infor: The Following Recored Is Deleted:\n";
			References[index]->printData();
			References[0] = nullptr;
			tailPosition--;
			return true;
		}
		else if (index == (tailPosition - 1)) {
			cout << "Infor: The Following Recored Is Deleted:\n";
			References[index]->printData();
			References[index] = nullptr;
			tailPosition--;
			return true;
		}
		else {
			cout << "Infor: The Following Recored Is Deleted:\n";
			References[index]->printData();
			for (int i{ index }; i < tailPosition - 1; ++i) {
				References[i] = References[i + 1];
			}
			References[tailPosition - 1] = nullptr;
			tailPosition--;
			return true;
		}
	}
	else {
		cout << "Erorr: The provided index is out of container range\n";
		getAllocatedContainerRange();
		return false;
	}
}
void ReferenceManager::getAllocatedContainerRange() {
	cout<< "The current allocated container range is " <<(tailPosition!=0?"from 0 to "+ to_string(tailPosition):"0")<<"\n";
}

bool  ReferenceManager::removeByID(int id) {
	if (tailPosition != 0) {
		for (int index{ 0 }; index < tailPosition; ++index) {
			if (References[index]->getUniqueIdentifier() == id) {
				removeByIndex(index);
				return true;
			}
		}
		cout << "Erorr: The provided ID is is not founded\n";
		return false;
	}
	else {
		cout << "Erorr: No Data, the container is empty\n";
		return false;
	}
}

bool  ReferenceManager::searchByIndex(int index) {
	// Sanity check our index value
	//assert(index >= 0 && index < tailPosition);
	if (index >= 0 && index < tailPosition) {
		int x;  cout << "Info: The provided index is founded\t\nEnter any number to print it, or 0 to cancel the process: "; cin >> x; if (x != 0) References[index]->printData(); cout << "\n";
		return true;
	}
	else {
		cout << "Erorr: The provided index is out of container range\n";
		getAllocatedContainerRange();
		return false;
	}
}

bool  ReferenceManager::searchByID(int id) {
	if (tailPosition != 0) {
		for (int index{ 0 }; index < tailPosition; ++index) {
			if (References[index]->getUniqueIdentifier() == id) {
				int x;  cout << "Info: The provided ID is founded.....\n(enter any number to print, or 0 to cancel): "; cin >> x; if (x != 0) References[index]->printData(); cout << "\n";
				return true;
			}
		}
		cout << "Erorr: The provided ID is is not founded\n";
		return false;
	}
	else {
		cout << "Erorr: No Data, the container is empty\n";
		return false;
	}
}



bool ReferenceManager::isFull()
{
	return (tailPosition >= size);
}

bool ReferenceManager::isEmpty()
{
	return (tailPosition <= 0);
}

ReferenceManager::~ReferenceManager()
{
	delete[] References;
	// we don't need to set m_data to null or m_length to 0 here, since the object will be destroyed immediately after this function anyway
}

void ReferenceManager::erase()
{
	delete[] References;
	// We need to make sure we set m_data to nullptr here, otherwise it will
	// be left pointing at deallocated memory!
	References = nullptr;
	tailPosition = 0;
}

void ReferenceManager::printData()
{
	if (!isEmpty()) {
		for (int i = 0; i < tailPosition; i++)
			References[i]->printData();
	}
	else {
		cout << "\n\nError Message: ** The Container Is Empty **\n\t\t\tYou Have " << getAvailableLocation() <<"  Available Locations..."<< endl;
	}
}

int ReferenceManager::getAvailableLocation() {
	return (size-tailPosition);
}

void ReferenceManager::printStorageInfo() {
	if (tailPosition == 0) {
		cout << "Erorr: The Container Is Empty\n";
	}
	cout << "Total location: " << size << "\tAllocated: " << tailPosition << "\tAvailable: " << size - tailPosition << endl;
}