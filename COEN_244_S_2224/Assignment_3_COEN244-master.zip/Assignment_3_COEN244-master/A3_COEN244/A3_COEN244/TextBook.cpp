#include "TextBook.h"
#include <iostream>

TextBook::TextBook() = default;

TextBook::TextBook(string Title, string Author, int YearOfPublication, string Publisher, int NumberOfPages, string WebURL) :
	Book(Title, Author, YearOfPublication, Publisher, NumberOfPages)
{
	setWebURL(WebURL);
}

TextBook& TextBook::operator=(const TextBook& orig)
{
	setUniqueIdentifier(orig.getUniqueIdentifier());
	setTitle(orig.getTitle());
	setAuthor(orig.getAuthor());
	setYearOfPublication(orig.getYearOfPublication());
	setPublisher(orig.getPublisher());
	setNumberOfPages(orig.getNumberOfPages());
	setWebURL(orig.getWebURL());
	return(*this);
}

string TextBook::getWebURL() const
{
	return string(webURL);
}

bool TextBook::setWebURL(string u)
{
	if (u != "") {
		webURL = u;
		return true;
	}
	else {
		cout << "Error: setWebURL..............." << endl;
		return false;
	}
}

void TextBook::printData() const {
	cout << "Type: TextBook" << endl;
	cout << "ID: " << getUniqueIdentifier() << endl;
	cout << "Title: " << getTitle() << endl;
	cout << "Author: " << getAuthor() << endl;
	cout << "Year: " << getYearOfPublication() << endl;
	cout << "Publisher: " << getPublisher() << endl;
	cout << "Total Page Number: " << getNumberOfPages() << endl;
	cout << "Web URL: " << getWebURL() << endl << endl;

}