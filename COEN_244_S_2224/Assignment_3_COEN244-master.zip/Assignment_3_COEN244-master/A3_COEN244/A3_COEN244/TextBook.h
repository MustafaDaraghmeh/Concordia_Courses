#pragma once
#include "Book.h"
class TextBook :
	public Book
{

public:
	TextBook();
	//
	TextBook(string Title, string Author, int YearOfPublication, string Publisher, int NumberOfPages, string WebURL);
	//
	TextBook& operator=(const TextBook& orig);

	//
	string getWebURL() const;

	//
	bool setWebURL(string u);

	//
	void printData() const;
private:
	string webURL;
};

