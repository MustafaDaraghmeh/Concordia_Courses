#include "Article.h"
#include <iostream>


Article& Article::operator=(const Article& orig) {
	setUniqueIdentifier(orig.getUniqueIdentifier());
	setTitle(orig.getTitle());
	setAuthor(orig.getAuthor());
	setYearOfPublication(orig.getYearOfPublication());
	setInformationAboutTheJournal(orig.getInformationAboutTheJournal());
	setStartPage(orig.getStartPage());
	setEndPage(orig.getEndPage());
	return(*this);
}

Article::Article() = default;

Article::Article(string Title, string Author, int YearOfPublication, string InformationAboutTheJournal, int StartPage, int EndPage) :
	Reference(Title, Author, YearOfPublication)
{
	setInformationAboutTheJournal(InformationAboutTheJournal);
	setStartPage(StartPage);
	setEndPage(EndPage);
}

// returns the total number of pages (computed using starPage and endPage
int Article::getNumberOfPages() const
{
	return (getEndPage() - getStartPage());
}
string Article::getInformationAboutTheJournal() const
{
	return string(informationAboutTheJournal);
}
int Article::getStartPage() const
{
	return startPage;
}
int Article::getEndPage() const
{
	return endPage;
}

bool Article::setInformationAboutTheJournal(string info)
{
	if (info != "") {
		informationAboutTheJournal = info;
		return true;
	}
	else {
		cout << "Error: setInformationAboutTheJournal..............." << endl;
		return false;
	}
}
bool Article::setStartPage(int s)
{
	if (s != NULL) {
		startPage = s;
		return true;
	}
	else {
		cout << "Error: setStartPage..............." << endl;
		return false;
	}
}
bool Article::setEndPage(int e)
{
	if (e != NULL) {
		endPage = e;
		return true;
	}
	else {
		cout << "Error: setEndPage..............." << endl;
		return false;
	}
}

void Article::printData() const {
	cout << "Type: Article" << endl;
	cout << "ID: " << getUniqueIdentifier() << endl;
	cout << "Title: " << getTitle() << endl;
	cout << "Author: " << getAuthor() << endl;
	Reference::printData();
	cout << "Year: " << getYearOfPublication() << endl;
	cout << "Information About The Journal: " << getInformationAboutTheJournal() << endl;
	cout << "Start Page: " << getStartPage() << endl;
	cout << "End Page: " << getEndPage() << endl;
	cout << "Total Page Number: " << getNumberOfPages() << endl << endl;

}