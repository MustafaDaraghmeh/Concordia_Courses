// A3_COEN244.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include <iostream>
#include "ReferenceManager.h"
#include "Article.h"
#include "Book.h"
#include "TextBook.h"


int LastTestIndex = 3;//[0-3] //size 4
string names[]{ "Mustafa","Ali","Joe","Ted" };
string titles[]{ "Machine Learing","Real Time Application","Networks","AI" };
string infos[]{ "Canada","USA","Jordan","French" };
string publishers[]{ "IEEE","ACM","MIT","Concordia" };
int years[]{ 2019,2018,1999,2005 };

void showOptions() {
	cout << "\n-------------------------------------------------------\n";
	cout << "\n************ Option List ************\n";
	cout << "1: Show The Container Recoreds.\n";
	cout << "2: Add Base Reference.\n";
	cout << "3: Add derived Article.\n";
	cout << "4: Add derived Book.\n";
	cout << "5: Add derived TextBook.\n";
	cout << "6: Search By Index.\n";
	cout << "7: Delete By Index.\n";
	cout << "8: Search By ID.\n";
	cout << "9: Delete By ID.\n";
	cout << "10: Show the Container Storage Information.\n";
}

int main()
{
	int const test_case = 1000;

	Reference References_arr[test_case]; int Reference_counter = 0;
	Article Article_arr[test_case]; int Article_counter = 0;
	Book Book_arr[test_case]; int Book_counter = 0;
	TextBook TextBook_arr[test_case]; int TextBook_counter = 0;


	//Create Default Container with 50 storage size
	const int size = 50;
	ReferenceManager ref(size);
	cout << "\nInfo: Default Container Is Created.... ( Default Storage Size Is 50)...\n";

	int select = -1;

	showOptions();

	cout << "\n(Type 0 To Exit)\nEnter Your Choice:"; cin >> select;
	cout << "\n-------------------------------------------------------\n";
	while(select){
		switch (select) {
		case 1: {
			ref.printData();
			break;
		}case 2: {
			References_arr[Reference_counter] = Reference(titles[rand() % LastTestIndex], names[rand() % LastTestIndex], years[rand() % LastTestIndex]);
			ref.add(References_arr[Reference_counter]);
			Reference_counter++;
			break;
		}case 3: {
			Article_arr[Article_counter] = Article(titles[rand() % LastTestIndex], names[rand() % LastTestIndex], years[rand() % LastTestIndex], infos[rand() % LastTestIndex], rand() % LastTestIndex + 15, rand() % (LastTestIndex + 15) + 100);
			ref.add(Article_arr[Article_counter]);
			Article_counter++;
			break;
		}case 4: {
			Book_arr[Book_counter] = Book(titles[rand() % LastTestIndex], names[rand() % LastTestIndex], years[rand() % LastTestIndex], publishers[rand() % LastTestIndex], rand() % LastTestIndex + 200);
			ref.add(Book_arr[Book_counter]);
			Book_counter++;
			break;
		}case 5: {
			TextBook_arr[TextBook_counter] = TextBook(titles[rand() % LastTestIndex], names[rand() % LastTestIndex], years[rand() % LastTestIndex], publishers[rand() % LastTestIndex], rand() % LastTestIndex + 200, "http://mustafa/refID?");
			ref.add(TextBook_arr[TextBook_counter]);
			TextBook_counter++;
			break;
		}case 6: {
			int index;
			cout << "\nSearch By Index: "; cin >> index;
			ref.searchByIndex(index);
			break;
		}case 7: {
			int index;
			cout << "\nDelete By Index: "; cin >> index;
			ref.removeByIndex(index);
			break;
		}case 8: {
			int id;
			cout << "\nSearch By ID: "; cin >> id;
			ref.searchByID(id);
			break;
		}case 9: {
			int id;
			cout << "\nDelete By ID: "; cin >> id;
			ref.removeByID(id);
			break;
		}case 10: {
			ref.printStorageInfo();
			break;
		}default: {
			printf("Enter the correct choice");
			break;
		}
		}

		showOptions();

		cout << "\n(Type 0 To Exit)\nEnter Your Choice:"; cin >> select;
		cout << "\n-------------------------------------------------------\n";
	}

	std::cout << std::endl;
}

