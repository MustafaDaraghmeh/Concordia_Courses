#pragma once
#include "Reference.h"

class ReferenceManager
{
public:
	ReferenceManager(int capacity);
	~ReferenceManager();
	void erase();
	void printData();
	int getAvailableLocation();
	void printStorageInfo();
	int getReferenceID(int pos) const;
	//bool add(string,string,int);
	bool add(Reference& orig);

	bool removeByIndex(int index);
	bool removeByID(int id);

	bool searchByID(int id);
	bool searchByIndex(int index);

	void getAllocatedContainerRange();


	//bool add(const Article& orig);
	bool isFull();

	bool isEmpty();

private:
	Reference** References = nullptr;
	int tailPosition;
	int size;
};


