#pragma once
#include "Reference.h"
class Article :
	public Reference
{
public:
	Article();
	Article(string Title, string Author, int YearOfPublication, string InformationAboutTheJournal, int StartPage, int EndPage);

	// returns the total number of pages (computed using starPage and endPage
	// (computed using starPage and endPage);
	int getNumberOfPages() const;

	string getInformationAboutTheJournal() const; //where the article is published
	int getStartPage() const;
	int getEndPage() const;

	bool setInformationAboutTheJournal(string info); //where the article is published
	bool setStartPage(int s);
	bool setEndPage(int e);

	void printData() const;

	Article& operator=(const Article& orig);

private:
	string informationAboutTheJournal; //where the article is published
	int startPage;
	int endPage;
};

