//
//  ReservationManager.cpp
//  Assignment 2
//
//  Created by  Mohammed Shehab & Mustafa Daraghmeh on 1/29/20.
//  Copyright � 2020  Mohammed Shehab & Mustafa Daraghmeh. All rights reserved.
//
#include <iostream>
#include <iomanip>      // std::setw
#include "ReservationManager.h"
using namespace std;

const int print_w = 15;

ReservationManager::ReservationManager()
{
	this->capacity = 0;
	this->reservation_table = new int* [6];// Set stations from enum
}

void ReservationManager::set_reservation_manager(int c)
{
	if (c > 0)
	{
		this->capacity = c;
		for (int i = 0; i < 6; ++i)
		{
			this->reservation_table[i] = new int[this->capacity]();
		}
	}
	else
	{
		cout << "Can't create array with size " << c << " <= 0\n";
	}
}

bool ReservationManager::request_reservation(Station start, Station destination, Date travel_time, Passenger p, int seats)
{
	// Check if there is avalible seats
	string direction = (start > destination? "RtL":"LtR");
	bool avalible = true;
	if (direction == "LtR") {
		for (int station = start; station < destination; station++)
		{//LtR
			int avalible_seats = 0;
			for (int seat = 0; seat < this->capacity; ++seat)
			{
				if (this->reservation_table[station][seat] == 0)
				{
					avalible_seats++;
					if (avalible_seats >= seats) break;
				}
			}
			if (avalible_seats < seats) {
				avalible = false;
			}
		}
	}
	else {//RtL
		for (int station = start; station > destination; station--)
		{
			int avalible_seats = 0;
			for (int seat = 0; seat < this->capacity; ++seat)
			{
				if (this->reservation_table[station][seat] == 0)
				{
					avalible_seats++;
					if (avalible_seats >= seats) break;
				}
			}
			if (avalible_seats < seats) {
				avalible = false;
			}
		}
	}

	if (direction == "LtR") {
		if (avalible)
		{
			ReservationRequest request = ReservationRequest();
			bool success = request.generate_reservation(p, travel_time, start, destination, seats);
			if (success)
			{
				for (int p_seat = 1; p_seat <= seats; ++p_seat) {
					// Need loop to store information
					for (int from = start; from < destination; from++) {
						for (int seat = 0; seat < this->capacity; ++seat)
						{
							if (reservation_table[from][seat] == 0) {
								this->reservation_table[from][seat] = request.get_reservation_number();
								break;
							}
						}
					}
				}

				this->requsts.push_back(request);
				cout << "Youe request is successfully complete.\n";
				cout << request;
			}
			else
			{
				cout << "-Error: Youe request is failed.\n";
			}
			return true;
		}
		else
		{
			cout << "Sorry no avaliable seats.\n";
			return false;
		}
	}
	else {
		if (avalible)
		{
			ReservationRequest request = ReservationRequest();
			bool success = request.generate_reservation(p, travel_time, start, destination, seats);
			if (success)
			{
				for (int p_seat = 1; p_seat <= seats; ++p_seat) {
					// Need loop to store information
					for (int from = start; from > destination; from--) {
						for (int seat = 0; seat < this->capacity; ++seat)
						{
							if (reservation_table[from][seat] == 0) {
								this->reservation_table[from][seat] = request.get_reservation_number();
								break;
							}
						}
					}
				}

				this->requsts.push_back(request);
				cout << "Youe request is successfully complete.\n";
				cout << request;
			}
			else
			{
				cout << "-Error: Youe request is failed.\n";
			}
			return true;
		}
		else
		{
			cout << "Sorry no avaliable seats.\n";
			return false;
		}
	}
}

string ReservationManager::station_to_str(int s)
{
	string str = "";
	switch (s)
	{
	case Montreal:
		str = "Montreal";
		break;
	case Dorval:
		str = "Dorval";
		break;
	case Brockville:
		str = "Brockville";
		break;
	case Kingston:
		str = "Kingston";
		break;
	case Belleville:
		str = "Belleville";
		break;
	case Toronto:
		str = "Toronto";
		break;
	case Notset:
		str = "-Not set-";
		break;
	}
	return str;
}

void ReservationManager::show_reservation_table()
{
	cout << "Request no\tStart\tDestination\tNo of passengers\n";
	for (size_t i = 0; i < requsts.size(); ++i)
	{
		cout << requsts[i].get_reservation_number() << "\t";
		cout << requsts[i].get_start() << "\t";
		cout << requsts[i].get_destination() << "\t";
		cout << requsts[i].get_seats() << "\t\n";
	}
}

void ReservationManager::show_seats()
{
	cout << "Seat no"<< setw(print_w);
	for (size_t i = 0; i < 6; i++)
	{
		cout << station_to_str(i) << setw(print_w);
	}
	
	cout << "\n";
	for (int seat = 0; seat < capacity; seat++)
	{
		cout << seat << setw(print_w);
		for (size_t i = 0; i < 6; i++)
		{
			cout << reservation_table[i][seat] << setw(print_w);
		}
		cout << "\r";
		cout << endl;
	}
}
