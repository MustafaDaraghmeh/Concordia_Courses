//
//  main.cpp
//  Assignment 2
//
//  Created by  Mohammed Shehab & Mustafa Daraghmeh on 1/27/20.
//  Copyright � 2020  Mohammed Shehab & Mustafa Daraghmeh. All rights reserved.
//

#include <iostream>
#include <vector>
#include "ReservationManager.h"
using namespace std;
Passenger* ps;
vector<Passenger> passengers;
ReservationManager manager; //= ReservationManager();
string names[] = { "Mohammed Ali", "Jak Smith", "Rui Zhao", "Mustafa Ahmed" };
Date bods[] = { Date(11, 30, 1987), Date(6, 27, 1992), Date(4, 5, 2000),Date(7, 10, 1985) };

void test()
{
	Date date_object = Date(11, 27, 1987);
	Date date_object2 = Date(9, 7, 1992);
	string name = "Mohammed Ali";

	Passenger p = Passenger(1, name, date_object);
	Date d = Date(2, 15, 2020);

	ReservationRequest test = ReservationRequest();
	test.generate_reservation(p, d, Montreal, Dorval, 3);
	cout << test;

	Passenger p1 = Passenger(2, "Alawi Shehab", date_object2);
	Date d2 = Date(6, 24, 2020);

	ReservationRequest test2 = ReservationRequest();
	test2.generate_reservation(p1, d2, Kingston, Toronto, 3);
	cout << test2;
}

void test2(int size)
{
	ps = new Passenger[size];
	for (int i = 0; i < 4; i++)
	{
		ps[i] = Passenger(i, names[i], bods[i]);
	}

	ReservationManager manager = ReservationManager();
	manager.set_reservation_manager(30);
	manager.request_reservation(Montreal, Kingston, Date(12, 3, 2020), ps[3], 2);
}

void create_passenger()
{
	string name;
	int m, d, y;
	cout << "Please enter the passenger name : ";
	cin >> name;
	cout << "Please enter Birth of date (Month): ";
	cin >> m;
	cout << "Please enter Birth of date (Day): ";
	cin >> d;
	cout << "Please enter Birth of date (Year): ";
	cin >> y;
	int id = (int)passengers.size() + 1;
	Date date = Date(m, d, y);
	Passenger passenger = Passenger(id, name, date);
	passengers.push_back(passenger);
	cout << "The passenger " << name << " added to the system.\n";
	cout << passenger.print();
	cout << "\n-----------------------------\n";
}

void add_reservation()
{
	int passenger_id;
	bool found = false;
	cout << "----Add Reservation----\n";
	cout << "Please enter passenger Id : ";
	cin >> passenger_id;
	//Search for passenger
	for (size_t i = 0; i < passengers.size(); i++)
	{
		if (passenger_id == passengers[i].get_id())
		{
			found = true;
			passenger_id = i;
			break;
		}
	}

	if (found)
	{
		int m, d, y;
		cout << "Please enter Reservation date (Month): ";
		cin >> m;
		cout << "Please enter Reservation date (Day): ";
		cin >> d;
		cout << "Please enter Reservation date (Year): ";
		cin >> y;
		Date date = Date(m, d, y);
		int start, end;
		Station from, to;
		cout << "1- Montreal\n2- Dorval\n3- Brockville\n4- Kingston\n5- Belleville\n6- Toronto\n";
		cout << "Please set the start station: ";
		cin >> start;
		switch (start) {
		case 1:from = Montreal; break;
		case 2:from = Dorval; break;
		case 3:from = Brockville; break;
		case 4:from = Kingston; break;
		case 5:from = Belleville; break;
		case 6:from = Toronto; break;

		default:cout << "Error please enter vaild city id [1,6]";
			return;
		}
		cout << "1- Montreal\n2- Dorval\n3- Brockville\n4- Kingston\n5- Belleville\n6- Toronto\n";
		cout << "Please set the destination station: ";
		cin >> end;
		switch (end) {
		case 1:to = Montreal; break;
		case 2:to = Dorval; break;
		case 3:to = Brockville; break;
		case 4:to = Kingston; break;
		case 5:to = Belleville; break;
		case 6:to = Toronto; break;
		default:cout << "Error please enter vaild city id [1,6]";
			return;
		}
		int seats;
		cout << "Enter seats count : ";
		cin >> seats;
		manager.request_reservation(from, to, date, passengers[passenger_id], seats);
	}
	else
	{
		cout << "Passanger with Id " << passenger_id << " is not found.\n";
	}
	return;
}

void print_reservation_table()
{
	manager.show_reservation_table();
}

void print_seats()
{
	manager.show_seats();
}

int main() {
	//    test2(4);
	manager = ReservationManager();
	int size;
	cout << "Welcome to system\nPlease set the size of train: ";
	cin >> size;
	manager.set_reservation_manager(size);
	int cho;
	do
	{
		cout << "1- add new passanger\n";
		cout << "2- add new reservation\n";
		cout << "3- print seats\n";
		cout << "4- print reservation table\n";
		cout << "Enter operation id: ";
		cin >> cho;
		switch (cho) {
		case 1:
			create_passenger();
			break;
		case 2:
			add_reservation();
			break;
		case 3:
			print_seats(); break;
		case 4: print_reservation_table(); break;
		default:
			break;
		}
	} while (cho >= 0);

	return 0;
}
