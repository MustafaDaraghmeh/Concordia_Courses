//
//  Passenger.h
//  Assignment 2
//
//  Created by  Mohammed Shehab & Mustafa Daraghmeh on 1/27/20.
//  Copyright � 2020  Mohammed Shehab & Mustafa Daraghmeh. All rights reserved.
//
#include <string>
#include <queue>
#include "Date.h"

using namespace std;

class Passenger
{
private:
	// Required by question
	int ID;
	string passenger_name;
	Date passenger_BOD;
	queue<int> trips;
	// Help flag
	const static int max_reservation = 5;

public:
	Passenger();
	Passenger(int, string, Date);
	bool is_trip_full();
	bool is_trip_empty();
	int get_trips_count();
	void set_trip(int);
	void operator = (Passenger);
	string print();
	int get_id();
	string get_name();
	Date get_BOD();
	queue<int> get_trips();
};
