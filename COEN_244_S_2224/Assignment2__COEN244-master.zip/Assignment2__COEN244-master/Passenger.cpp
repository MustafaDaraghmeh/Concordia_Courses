//
//  Passenger.cpp
//  Assignment 2
//
//  Created by  Mohammed Shehab & Mustafa Daraghmeh on 1/27/20.
//  Copyright � 2020  Mohammed Shehab & Mustafa Daraghmeh. All rights reserved.
//
#include <iostream>
#include "Passenger.h"
using namespace std;

Passenger::Passenger()
{
	this->passenger_name = "";
	this->passenger_BOD = Date();
}

Passenger::Passenger(int id, string name, Date date_object)
{
	if (name.size() > 0)
	{
		this->passenger_name = name;
		this->passenger_BOD = date_object;
		this->ID = id;
	}
	else
	{
		cout << "Error: invalid Passenger name, please set Passenger name not empty.\n";
		cout << "Be sure you send correct args Passenger(string passenger_name, Date data_object)";
		return;
	}
}

bool Passenger::is_trip_empty()
{
	return this->trips.empty();
}

bool Passenger::is_trip_full()
{
	return (this->trips.size() == this->max_reservation);
}

int Passenger::get_trips_count()
{
	return (int)(this->trips.size());
}

int Passenger::get_id()
{
	return this->ID;
}

string Passenger::get_name()
{
	return this->passenger_name;
}

Date Passenger::get_BOD()
{
	return this->passenger_BOD;
}

queue<int> Passenger::get_trips()
{
	return this->trips;
}

void Passenger::operator=(Passenger p)
{
	if (p.get_name().size() > 0)
	{
		this->passenger_name = p.get_name();
		this->passenger_BOD = p.get_BOD();
		this->ID = p.get_id();
	}

}

string Passenger::print()
{
	string info = "Passenger name : " + this->get_name();
	info += "\nPassenger ID : " + to_string(this->get_id()) + "\n";
	return info;
}

void Passenger::set_trip(int trip_id)
{
	this->trips.push(trip_id);
}
