//
//  ReservationRequest.h
//  Assignment 2
//
//  Created by  Mohammed Shehab & Mustafa Daraghmeh on 1/27/20.
//  Copyright � 2020  Mohammed Shehab & Mustafa Daraghmeh. All rights reserved.
//
#include "Passenger.h"
//#include "Date.h"
#include <iostream>

enum Station {
	Montreal = 0,
	Dorval = 1,
	Brockville = 2,
	Kingston = 3,
	Belleville = 4,
	Toronto = 5,
	Notset = -1
};

class ReservationRequest
{
private:
	Passenger passenger;
	static int reservation_request_number;
	int reservation_number;
	Date travelling_date;
	Station start;
	Station destination;
	int seats;

public:
	ReservationRequest();
	bool generate_reservation(Passenger, Date, Station, Station, int);
	Passenger get_passenger();
	int get_reservation_number();
	Date get_travel_date();
	Station get_start();
	Station get_destination();
	int get_seats();
	friend ostream& operator << (ostream& shihab, ReservationRequest& c);
};
