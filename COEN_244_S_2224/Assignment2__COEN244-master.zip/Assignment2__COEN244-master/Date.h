//
//  Date.h
//  Assignment 2
//
//  Created by  Mohammed Shehab & Mustafa Daraghmeh on 1/27/20.
//  Copyright � 2020  Mohammed Shehab & Mustafa Daraghmeh. All rights reserved.
//
#include<string>
using namespace std;

class Date
{
private:
	int month, day, year;
public:
	Date();
	Date(int, int, int);
	void set_date(int, int, int);
	void operator = (Date);
	string get_date();
	int get_m();
	int get_d();
	int get_y();
};

