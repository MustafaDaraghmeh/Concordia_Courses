//
//  ReservationRequest.cpp
//  Assignment 2
//
//  Created by  Mohammed Shehab & Mustafa Daraghmeh on 1/27/20.
//  Copyright � 2020  Mohammed Shehab & Mustafa Daraghmeh. All rights reserved.
//
#include <iostream>
#include "ReservationRequest.h"
//#include "Passenger.h"
//#include "Date.h"
using namespace std;

int ReservationRequest::reservation_request_number = 0;

ReservationRequest::ReservationRequest()
{
	this->passenger = Passenger();
	this->travelling_date = Date();
	this->start = Notset;
	this->destination = Notset;
	this->seats = 0;
	this->reservation_number = 0;
}

bool ReservationRequest::generate_reservation(Passenger p, Date d, Station s, Station e, int seats)
{
	if (seats > 4)
	{
		cout << "Error the maximum number of seats is 4, ";
		cout << "and you set it = " << seats << "\n";
		cout << "Note: generate_reservation(Passenger object, Date travelling_date, Station start, Station destination, int seats_number)\n";
		return false;
	}
	else
	{
		this->passenger = p;
		this->travelling_date = d;
		this->start = s;
		this->destination = e;
		this->seats = seats;
		ReservationRequest::reservation_request_number++;
		this->reservation_number = ReservationRequest::reservation_request_number;
		return true;
	}
}

Passenger ReservationRequest::get_passenger()
{
	return this->passenger;
}

int ReservationRequest::get_reservation_number()
{
	return this->reservation_number;
}

Date ReservationRequest::get_travel_date()
{
	return this->travelling_date;
}

Station ReservationRequest::get_start()
{
	return this->start;
}

Station ReservationRequest::get_destination()
{
	return this->destination;
}

int ReservationRequest::get_seats()
{
	return this->seats;
}

ostream& operator << (ostream& shihab, ReservationRequest& c)
{
	shihab << "Reservation Request : " << c.get_reservation_number() << "\n";
	shihab << c.get_passenger().print();
	shihab << "Reservation Date : " << c.get_travel_date().get_date() << endl;

	switch (c.get_start())
	{
	case Montreal:
		shihab << "From : Montreal\n";
		break;
	case Dorval:
		shihab << "From : Dorval\n";
		break;
	case Brockville:
		shihab << "From : Brockville\n";
		break;
	case Kingston:
		shihab << "From : Kingston\n";
		break;
	case Belleville:
		shihab << "From : Belleville\n";
		break;
	case Toronto:
		shihab << "From : Toronto\n";
		break;
	case Notset:
		shihab << "From : -Notset-\n";
		break;
	}

	switch (c.get_destination())
	{
	case Montreal:
		shihab << "To : Montreal\n";
		break;
	case Dorval:
		shihab << "To : Dorval\n";
		break;
	case Brockville:
		shihab << "To : Brockville\n";
		break;
	case Kingston:
		shihab << "To : Kingston\n";
		break;
	case Belleville:
		shihab << "To : Belleville\n";
		break;
	case Toronto:
		shihab << "To : Toronto\n";
		break;
	case Notset:
		shihab << "To : -Notset-\n";
		break;
	}
	shihab << "Take " << c.get_seats() << " seat(s).\n";
	shihab << "---------------------------------\n";
	return shihab;
}
