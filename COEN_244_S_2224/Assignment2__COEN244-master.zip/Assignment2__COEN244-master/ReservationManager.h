//
//  ReservationManager.h
//  Assignment 2
//
//  Created by  Mohammed Shehab & Mustafa Daraghmeh on 1/29/20.
//  Copyright � 2020  Mohammed Shehab & Mustafa Daraghmeh. All rights reserved.
//
#include "ReservationRequest.h"
#include <vector>
class ReservationManager
{
private:
	int capacity;
	int** reservation_table;
	vector<ReservationRequest> requsts;
	string station_to_str(int);
public:
	ReservationManager();
	void set_reservation_manager(int);
	bool request_reservation(Station, Station, Date, Passenger, int);
	void show_reservation_table();
	void show_seats();
};
