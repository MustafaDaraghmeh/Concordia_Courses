//
//  Date.cpp
//  Assignment 2
//
//  Created by  Mohammed Shehab & Mustafa Daraghmeh on 1/27/20.
//  Copyright � 2020  Mohammed Shehab & Mustafa Daraghmeh. All rights reserved.
//

//#include <stdio.h>
#include "Date.h"
#include <iostream>
using namespace std;

Date::Date()
{
	month = 1;
	day = 1;
	year = 1970;
}

Date::Date(int m, int d, int y)
{
	    if(m > 0 && m < 13)
	    {
	        this->month= m;
	    }
	    else
	    {
	        cout<<"Error: invalid date, you should set month between [1,12]\n";
	        cout<<"while you set m "<<m<<" Date(int month, int day, int year).\n";
	        return;
	    }
	
	    if(d > 0 && d < 32)
	    {
	        this->day = d;
	    }
	    else
	    {
	        cout<<"Error: invalid date, you should set month between [1,31]\n";
	        cout<<"while you set d "<<d<<" Date(int month, int day, int year).\n";
	        cout<<"- Note: month is reset to be 1, because take failed.";
	        this->month = 1;
	        return;
	    }
	
	    if(y > 1969 && y <= 2020)
	    {
	        this->year = y;
	    }
	    else
	    {
	        cout<<"Error: invalid date, you should set month between [1969,2020]\n";
	        cout<<"while you set y "<<y<<" Date(int month, int day, int year).\n";
	        cout<<"- Note: month is reset to be 1, because take failed.";
	        cout<<"- Note: day is reset to be 1, because take failed.";
	        this->month = 1;
	        this->day = 1;
	        return;
	    }
	//set_date(m, d, y);
}

int Date::get_m()
{
	return this->month;
}
int Date::get_d()
{
	return this->day;
}
int Date::get_y()
{
	return this->year;
}

void Date::set_date(int m, int d, int y)
{
	    Date(m, d, y);
}

void Date::operator=(Date obj)
{
	this->set_date(obj.get_m(), obj.get_d(), obj.get_y());
}

string Date::get_date()
{
	string formated_date = to_string(this->day) + " - ";

	switch (this->month) {
	case 1:
		formated_date += "Jan - ";
		break;
	case 2:
		formated_date += "Feb - ";
		break;
	case 3:
		formated_date += "Mar - ";
		break;
	case 4:
		formated_date += "Apr - ";
		break;
	case 5:
		formated_date += "May - ";
		break;
	case 6:
		formated_date += "Jun - ";
		break;
	case 7:
		formated_date += "Jul - ";
		break;
	case 8:
		formated_date += "Aug - ";
		break;
	case 9:
		formated_date += "Sep - ";
		break;
	case 10:
		formated_date += "Oct - ";
		break;
	case 11:
		formated_date += "Nov - ";
		break;
	case 12:
		formated_date += "Dec - ";
		break;
	default:
		break;
	}

	return formated_date + to_string(this->year);
}
